<?php
// Collect form data
$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];

// Store data in a local file
$data = "$name,$email,$message\n";
file_put_contents('data.txt', $data, FILE_APPEND);
?>