const firebaseConfig = {
    apiKey: "AIzaSyAn14GpI7ZRTBPqDvvJUY7DQ5KFv7vnU-U",
    authDomain: "healthy-india-portal.firebaseapp.com",
    databaseURL: "https://healthy-india-portal-default-rtdb.firebaseio.com",
    projectId: "healthy-india-portal",
    storageBucket: "healthy-india-portal.appspot.com",
    messagingSenderId: "497811410799",
    appId: "1:497811410799:web:7d79b4eab71ce2b366229a"
  };